<?php
/**
 * Created by PhpStorm.
 * User: amit raj
 * Date: 12-Nov-18
 * Time: 11:45 AM
 */

function wpmu_list_sites() {

	$subsites = get_sites();

	if ( ! empty ( $subsites ) ) {

		echo '<ul class="subsites">';

		foreach( $subsites as $subsite ) {

			$subsite_id = get_object_vars( $subsite )["blog_id"];
			$subsite_name = get_blog_details( $subsite_id )->blogname;
			$subsite_link = get_blog_details( $subsite_id )->siteurl;
			echo '<li class="site-' . $subsite_id . '"><a href="' . $subsite_link . '">' . $subsite_name . '</a></li>';

		}

		echo '</ul>';

	}

}
add_action( 'wpmu_before_header', 'wpmu_list_sites' );